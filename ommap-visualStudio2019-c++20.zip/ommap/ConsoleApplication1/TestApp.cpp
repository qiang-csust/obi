﻿// ConsoleApplication1.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#define _CRT_SECURE_NO_WARNINGS
import qiang.csust.obi;

#include "common.h"
#include <vector>
#include <string>
using namespace std;

void testPerformance1()
{
	int L = 15;
	int S = 4;
	int Z = 4;
	vector<unsigned long long> ids;
	for (int i = 15; i < 23; i++)
	{
		OMMAP tree(i, S, Z);
		for (int j = 0; j < 1024; j++)
		{
		//	tree.add("w", j);
			ids.push_back(j);
		}
		tree.add(string("w"), ids,false,true);
		
		tree.search("w", ids,true);
	}
}
void testPerformance2()
{
	int L = 15;
	int S = 4;
	int Z = 4;
	vector<IndexValue> values;
	for (int i = 15; i < 23; i++)
	{
		OMMAP tree(i, S, Z);
		for (int j = 0; j < 1024; j++)
		{			
			IndexValue v;
			v.writeString(string("str:") + IntToStr(j));
			values.push_back(v);
		}
		tree.add("w", values,false,true);
		tree.search("w", values, true);
	}
}

void testOMMAP()
{
	OMMAP tree(10, 4, 4);
	tree["address"] = { "Computer Science and Communication Engineering","Changsha University of Science and Technology","China","410000"};
	tree["author"] = {"Dr. Zhiqiang Wu","wzq@csust.edu.cn", "http://www.csust.edu.cn"};
	vector<IndexValue> v;
	tree.search("author", v, true);
	tree.search("address", v, true);

}

int main(int c,char* argv[])
{
	printf("A single-round-trip bulk-insert oblivious mulimap\r\n\r\n");
	printf("OBI-OMMAP v1.0, programed by Zhiqiang Wu, wzq@csust.edu.cn\r\n\r\n");
	testOMMAP(); getchar();
	testPerformance1(); getchar();
	testPerformance2(); getchar();
	printf("\r\n\r\n");
	getchar();
}
