Copy OBI.exe to the current directory.
Download "enron_mail_20150507.tgz" from "https://www.cs.cmu.edu/~./enron/"
Copy the unzipped Enron dataset to "E:\OBindex\maildir"
Run "createindex_enron.bat" to create a full plain-text inverted index.
Run "search.bat" to enter the OBI console.
