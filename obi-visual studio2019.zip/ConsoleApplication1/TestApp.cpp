﻿// ConsoleApplication1.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#define _CRT_SECURE_NO_WARNINGS
#include "common.h"
#include <conio.h> //kbhit
#include <iostream>
#include <unordered_map>
#include "CPath64.h"
#include "myhash.h"
#include "myAES.h"
#include "testClass.h"
#include "Myhashtable.h"
#include "ORAMtree.h"
#include "CInvertedIndex.h"
#include "CashSSE.h"
#include <vector>
#include <string>
using namespace std;



//void pathoram_old_test()
//{
//	PathORAM2 oram(4);
//
//	DataBlock b2 = { 0 };
//	for (int i = 0; i < 7; i++)
//	{
//		DataBlock b;
//		b.v = i * 2;
//		oram.access("write", i, false, b);
//	};
//
//	//for (int i = 0; i < 7; i+=2)
//	//{
//	//	DataBlock b;
//	//	b.v = i * 3;
//	//	oram.access("write", i, false, b);
//	//};
//
//	for (int i = 0; i < 7; i++)
//	{
//		oram.access("read", i, false, b2);
//		cout << i << "," << b2.v << "\r\n";
//	}
//}
//
//void pathoram_test()
//{
//	PathORAM<int> oram(32);
//	//oram.bDebug = false;
//	//string s1 = oram.GetSibling("001");
//	//string s2 = oram.GetSibling("010");
//	//string s3 = oram.GetSibling("110");
//	//string s4 = oram.GetSibling("101");
//	//string s=oram.P(2, 2,3);
//	//cout << s;
//	//getchar();
//	//DataBlock b2,b3;
//
//	//b2.v = 3;
//	//oram.access("write", 0, false, b2);
//	//oram.access("read", 0, false, b3);
//	//cout << b3.v;
//
//	DataBlock b2 = { 0 };
//	//for (int i = 0; i < 7; i++)
//	//{
//	//	DataBlock b;
//	//	b.v = i * 2;
//	//	oram.access("write", i, false, b);
//	//};
//
//	//for (int i = 0; i < 7; i++)
//	//{
//	//	DataBlock b;
//	//	b.v = 5 * 3;
//	//	oram.access("write", 5, false, b);
//	//}
//
//	DataBlock b1,bb2;
//	b1.v = 1000;
//	//oram.access("write", 1, false, b1);
//	bool bError = false;
//	oram.write(0, false, 999);
//	for (int j = 2; j < 3; j++)
//	{
//		DataBlock b;
//		b.v = rand32()%1000;
//
//		//oram.access("write", 1, false, b);
//		for (int k = 0; k < 10; k++)
//		{
//			oram.access("write", j,  b);
//		}
//		
//
//		for (int i = 0; i < 1000; i++)
//		{
//			oram.access("read", j,  b2);
//			if (b2.v != b.v)
//			{
//				cout << "error! i=" << i<<",j="<<j<<",b.v="<<b.v<<",b2.v="<<b2.v<<endl;
//				bError = true;
//				getchar();
//			}
//		}
//	}
//
//	//oram.access("read", 1, false, bb2);
//	for (int i = 0; i < 100; i++)
//	{
//		int c = oram.read(0, false);
//		if (c != 999)
//		{
//			cout << "failure,c=" << c<<",i="<<i;
//			bError = true;
//			getchar();
//		};
//	}
//	if(!bError)
//	cout << "OK! ";
//
//}
//void pathoram_test2()
//{
//	PathORAM<int> oram(32);
//	//string s1 = oram.GetSibling("001");
//	//string s2 = oram.GetSibling("010");
//	//string s3 = oram.GetSibling("110");
//	//string s4 = oram.GetSibling("101");
//	//string s=oram.P(2, 2,3);
//	//cout << s;
//	//getchar();
//	//DataBlock b2,b3;
//
//	//b2.v = 3;
//	//oram.access("write", 0, false, b2);
//	//oram.access("read", 0, false, b3);
//	//cout << b3.v;
//
//	DataBlock b2 = { 0 };
//	//for (int i = 0; i < 7; i++)
//	//{
//	//	DataBlock b;
//	//	b.v = i * 2;
//	//	oram.access("write", i, false, b);
//	//};
//
//	//for (int i = 0; i < 7; i++)
//	//{
//	//	DataBlock b;
//	//	b.v = 5 * 3;
//	//	oram.access("write", 5, false, b);
//	//}
//
//	DataBlock b1, bb2;
//	b1.v = 1000;
//	//oram.access("write", 1, false, b1);
//	bool bError = false;
//	oram.write(0, false, 999);
//	for (int j = 2; j < 20000; j++)
//	{
//		DataBlock b;
//		b.v = rand32() % 1000;
//
//		//oram.access("write", 1, false, b);
//		for (int k = 0; k < 10; k++)
//		{
//			oram.access("write", j,  b);
//		}
//
//
//		for (int i = 0; i < 1000; i++)
//		{
//			oram.access("read", j,  b2);
//			if (b2.v != b.v)
//			{
//				cout << "error! i=" << i << ",j=" << j << ",b.v=" << b.v << ",b2.v=" << b2.v << endl;
//				bError = true;
//				getchar();
//			}
//		}
//	}
//
//	//oram.access("read", 1, false, bb2);
//	for (int i = 0; i < 100; i++)
//	{
//		int c = oram.read(0, false);
//		if (c != 999)
//		{
//			cout << "failure,c=" << c << ",i=" << i;
//			bError = true;
//			getchar();
//		};
//	}
//	if (!bError)
//		cout << "OK! ";
//
//}
//
////void test_fun()
////{
////	PathORAM oram(4);
////	unordered_map<Mem20, Mem24, hash_func, cmp_fun> tb;
////	Mem20 sk = { 0 };
////	for (int i = 0; i < 20; i++) sk.bytes[i] = i%256;
////	Mem20 seed = { 0 }; for (int i = 0; i < 20; i++) seed.bytes[i] = i % 10;
////	unsigned long pos = 100;
////	//bool PathORAM::ReadPosition(, Mem20& searchKey, unsigned long& pos, Mem20 &seed_in_leaf)
////	oram.WritePosition(tb, sk, pos, seed);
////	Mem20 seed1 = { 0 };
////	unsigned long pos1 = 0;
////	oram.ReadPosition(tb, sk, pos1, seed1);
////}
//
//
//
//void test(int L)
//{
//	PathORAM<int> oram(1);
//	oram.SetL(L);
//	oram.bDebug = false;
//	oram.bDebugMask = false;
//	double t1 = time_ms();
//	//oram.write(0, false, 999);
//	int max = oram.capacity ;
//	for (int i = 0; i < max; i++)
//	{
//		int a = i % max;
////		printf("write %d=>%d\r\n", i, 1000 + i);
////		oram.dump();
//		oram.write(a, false, 1000+a);
////		oram.DebugCheckNodes();
////		getchar();
//		//
//	}
//
//	for (int i = 0; i < max; i++)
//	{
//		int a = i % max;
//	//	printf("read %d,\r\n", i );
//	//	oram.dump();
//		int vv = oram.read(a, false);
//		if (vv != 1000+a)
//		{	
//			//oram.DumpDebugLastAccessedLeaves();
//			oram.DebugCheckORAMIntegrity(i);
//			oram.DebugCheckNodes();
//			cout << "error!" << "vv=" << vv << ",i=" << i  << "\r\n";
//			getchar();
//		}
//	}
//	//int v1 = oram.read(0, false);
//	//if (v1 != 999)
//	//{
//	//	cout << "error!=999," << "v1=" << v1 << "\r\n";
//	//	oram.DumpDebugLastAccessedLeaves();
//	//	getchar();
//	//}
//	double t2 = time_ms();
//	//oram.dump();
//	//oram.dumpfile("expe.txt");
//	string filename = string("expe_") + IntToStr(L) + ".txt";
//	oram.dumpfile(filename);
//	FILE* fp = fopen(filename.c_str(), "ab+");
//	fprintf(fp, "test0 L=%d, Z_block=%d,time =%f(ms), speed=%f(pair/s)\r\n", L, Z_block, t2 - t1,max/(t2-t1)*1000.);
//	fclose(fp);
//	printf("completed!\r\n");
//}
//
//
//void testStash(int L)
//{
//	PathORAM<int> oram(1);
//	oram.SetL(L);
//	oram.bDebug = false;
//	oram.bDebugMask = false;
//	double t1 = time_ms();
//	//oram.write(0, false, 999);
//	int max = oram.capacity;
//	for (int i = 0; i < max; i++)
//	{
//		int a = i % max;
//		//		printf("write %d=>%d\r\n", i, 1000 + i);
//		//		oram.dump();
//		oram.write(a, false, 1000 + a);
//		oram.write(1, false, 1000 + a);
//		//		oram.DebugCheckNodes();
//		//		getchar();
//				//
//	}
//
//	double t2 = time_ms();
//	//oram.dump();
//	//oram.dumpfile("expe.txt");
//	string filename = string("expe_") + IntToStr(L) + ".txt";
//	//oram.dumpfile(filename);
//	oram.dumpStash();
//	FILE* fp = fopen(filename.c_str(), "ab+");
//	fprintf(fp, "test0 L=%d, Z_block=%d,time =%f(ms), speed=%f(pair/s)\r\n", L, Z_block, t2 - t1, max / (t2 - t1)*1000.);
//	fclose(fp);
//	printf("test0 L=%d, Z_block=%d,time =%f(ms), speed=%f(pair/s)\r\n", L, Z_block, t2 - t1, max / (t2 - t1)*1000.);
//	printf("completed!\r\n");
//}
//
//void test10()
//{
//	PathORAM<int> oram(31);
//	oram.bDebug = false;
//	oram.write(0, false, 666);
//	double t1 = time_ms();
//	int b1 = myhash::counter();
//	int c = oram.read(0, false);
//	int b2 = myhash::counter();
//	double t2 = time_ms();
//	printf("test1 time =%f(ms) blake2b=%d, c=%d \r\n", t2 - t1, b2 - b1, c);
//	//oram.dump();
//}
//
//void test1()
//{
//	int L = 19;
//	PathORAM<int> oram(L);
//	oram.bDebug = false;
//	//double t1 = time_ms();
//	//int b1 = myhash::counter();
//	oram.write(0,false,999);
//	//oram.SetL(10);
//	//oram.write(0, false, 777);
////	oram.SetL(5);
//	double t1 = time_ms();
//	for (int i = 0; i < oram.capacity; i++)
//	{
//	//	printf("\r\n write addr=%d:\r\n", i);
//	//	oram.dump();
//		oram.write(i, false, 100 + i);
//	//	oram.DumpDebugLastAccessedLeaves();
//		//
//		//if ((i >= 70472)&&(i<=70474))
//		//{
//		//	printf("--------------\r\n at i=%d \r\n", i);
//		//	bool ret=oram.DebugCheckORAMIntegrity(70472);
//		//	oram.dumpStash();
//		//}
//	}
//	//oram.dump();
//	//int j = oram.read(0, false);
//	////
//	//oram.DumpDebugLastAccessedLeaves();
//	//getchar();
//	//oram.dump();
//	//oram.dumpData();
//	int oldC = oram.capacity;
//	//oram.SetL(L+2);
//	//oram.dump();
//	for (int i = 0; i < oldC; i++)
//	{
//		//printf("\r\n read addr=%d:\r\n", i);
//		//oram.dump();
//		//if ((i >= 70472-100) && (i<=70472))
//		//{
//		//	oram.DebugCheckORAMIntegrity(70472);
//		//}
//		int j=oram.read(i, false);
//	//	oram.DumpDebugLastAccessedLeaves();
//		//oram.dump();
//		if (j != 100+i)
//		{
//			//int j2 = oram.read(i, false);
//			//oram.dump();
//			oram.dumpfile("error.txt");
//			oram.dump();
//			printf("\r\n Error!j=%d i=%d \r\n", j, i);
//			oram.DumpDebugLastAccessedLeaves();
//			FILE* fp = fopen("error.txt", "ab+");
//			fprintf(fp,"\r\n Error!j=%d i=%d \r\n", j, i);
//			fclose(fp);
//
//			getchar();
//		}
//	}
//
//	//int b1 = myhash::counter();
//	int c=oram.read(0, false);
//	//int b2 = myhash::counter();
//	double t2 = time_ms();
//	//int c2 = 0;// oram.read(16, false);
//	//printf("test1 time =%f(ms) blake2b=%d, c=%d ,c2=%d\r\n", t2 - t1,b2-b1,c,c2);
//	cout << "c="<<c<< " time=" << t2-t1<<"\r\n";//1.86ms 每次插入删除，
//	oram.dumpData();
//	//oram.DumpDebugLastAccessedLeaves();
//	//oram.dump();
//}
//
//void test2()
//{
//	//int L = 4;
//	PathORAM<int> oram(3);
//	oram.bDebug = true;
//	//double t1 = time_ms();
//	//int b1 = myhash::counter();
//	oram.write(0, false, 999);
//	int v=oram.read(0, false);
//	oram.DumpDebugLastAccessedLeaves();
//	//oram.DebugCheckNodes();
//	oram.dumpM();
//	cout << "v=" << v;
//}
//void testSpeed()
//{
//	int L = 10;
//	PathORAM<int> oram(L);
//	oram.bDebug = false;
//	double t1 = time_ms();
//	for (int i = 0; i < oram.capacity; i++)
//	{
//		oram.write(i, false, 100 + i);
//	}
//	double t2 = time_ms();
//	oram.dumpData();
//	oram.dumpStash();
//	cout <<"L="<<L<<", time=" << t2 - t1 << "(ms), speed="<<oram.capacity/(t2-t1)*1000. <<"(tuple/s) \r\n";//1.86ms 每次插入删除，
//	//oram.DumpDebugLastAccessedLeaves();
//	//oram.dump();
//}
//
//void testAES()
//{
//	PathORAM<int> p(16);
//	Tail t;
//	t.blocks[0].a = 1;
//	t.blocks[1].a = 2;
//	t.blocks[2].a = 3;
//
//	vector<byte> b = p.ToETail(t);
//	Tail t2=p.ToTail(b);
//	printf("%d %d %d \r\n", t2.blocks[0].a, t2.blocks[1].a,t2.blocks[2].a);
//	getchar();
//	myAES::SetPrivateKey((char*)"password");
//	char teststr[17] = { "hello world!1234" };
//	char output[64] = { 0 };
//	int outlen;
//	myAES::Encrypt(teststr, strlen(teststr), output, outlen);
//	char out2[64] = { 0 };
//	int outlen2 = 0;
//	myAES::Decrypt(output, outlen, out2, outlen2);
//	char output3[64] = { 0 };
//	myAES::Encrypt(teststr, strlen(teststr), output3, outlen);
//	for (int i = 0; i < outlen; i++)
//	{
//		printf("i=%d %.2x %.2x\r\n", i,(byte)output[i], (byte)output3[i]);
//	}
//
//	printf("%s len=%d", out2,outlen2);
//}

/*
struct TestS
{
	int x;
	int y;
	int z;
};

void testDraw()
{
	PathORAM<TestS> oram(4);
	oram.bDebugShuffle = false;
	//for (int i = 0; i < oram.capacity; i++)
	//{
	//	printf("//write i=%d, %d \r\n", i, 100+i);
	//	oram.write(i, 100 + i);
	//	oram.dumpTree();
	//}
	printf("//write i=%d, %d \r\n", 1, 101);
	TestS s;
	s.x = 100;
	oram.write(1, s);
	oram.dumpTree();
	printf("//read i=%d, %d \r\n", 1, 101);
	TestS v=oram.read(1);
	oram.dumpTree();
	printf("v=%d", v.x);
	//oram.read(1);
	//oram.dumpTree();
	//oram.read(1);
	//oram.dumpTree();

}

struct B80
{
	Mem20 m1;
	Mem20 m2;
	Char20 c1;
	Char20 c2;
};
void testSingleRound()
{
	PathORAM<__int64> oram(4);
	__int64 v = 123456789;
	oram.single_round_access("write", 2, v);
	v = 22222;
	oram.single_round_access("write", 3, v);
	v = 11111;
	//oram.single_round_access("write", 0, v);
	__int64 v2;
	oram.single_round_access("read", 2, v2);
	printf("%lld\r\n", v2);
	oram.single_round_access("read", 0, v2);
	printf("%lld", v2);

	PathORAM<B80> oram2(16);	
	B80 b1 = { "abcd","abcd",{"abcd",4},{"abcd",4} }, b2;
	
	oram2.single_round_access("write", 2, b1);
	oram2.single_round_access("read", 2, b2);
	printf("%s\r\n", b2.m1);

	PathORAM<R> oram3(16);
	R r1= { "abcdefg" };
	R r2 = { 0 };
	oram3.single_round_access("write", 2, r1);
	oram3.single_round_access("read", 2, r2);
	printf("%s", r2.c1);
}


void testHashtable()
{
	OHashTable tb(16);
	double t1 = time_ms();
	tb.writestring("hello","world!");
	string v = tb.readstring("hello");
	tb.deleteByString("hello");
	v = tb.readstring("hello");
	tb.writestring("hello", "world!");
	double t2 = time_ms();
	printf("%s time=%f(ms)", v.c_str(),t2-t1);
};

void testHashtablePerformance()
{
	OHashTable tb(8);
	int max = pow(2, 8) - 1;
	int c = 2 * max;
	for (int i = 0; i < c; i++)
	{
		string k = IntToStr(i);
		string v = IntToStr(2 * i);
		tb.writestring(k, v);
	}
	printf("capacity=%d, total search length=%d, average search length=%f, rounds=%d\r\n",max, tb.DebugSearchLength,(double)tb.DebugSearchLength/c, tb.DebugReadWriteRound);
	for (int i = 0; i < c; i++)
	{
		string k = IntToStr(i);
		string v1=tb.readstring(k);
		string v = IntToStr(2 * i);
		if (v1 != v)
		{
			printf("error! i=%d, v1=%s v=%s",i, v1.c_str(),v.c_str()); getchar();
		}
	}
}
void testPathORAMInsertSpeed()
{
	int data1 = 88888;
	for (int i = 4; i < 64; i++)
	{
		PathORAM<int> oram(i);
		for (int j = 0; j < 1024; j++)
		{
			oram.single_round_access("write", j % (oram.capacity), data1);
		}
		double t1 = time_ms();
		oram.single_round_access("write", 12345%(oram.capacity), data1);
		double t2 = time_ms();
		printf("L=%d write time=%f bandwidth=%d bytes \r\n", i, t2 - t1,oram.request_bytes);
		int data2;
		oram.single_round_access("read", 12345 % (oram.capacity), data2);
		if (data2 != data1)
		{
			printf("error!\r\n");
		}
	}
}
void testFixedSizePathORAMInsertSpeed()
{
	int data1 = 88888;
		PathORAM<int> oram(20);
		printf("testFixedSizePathORAMInsertSpeed:\r\n");
		for (int i = 0; i < oram.capacity; i++)
		{
			oram.single_round_access("write", i % (oram.capacity), data1);

			if ((i == 1024) || (i == 1024 * 2) || (i == 1024 * 4) || (i == 1024 * 8) || (i == 1024 * 16) || (i == 1024 * 32) || (i == 1024 * 64) || (i == 1024 * 128) || (i == 1024 * 256) || (i == 1024 * 512) || (i == 1024 * 1024) || (i == 1024 * 2048))
			{
				int data2;
				double t1 = time_ms();
				oram.single_round_access("read", i % (oram.capacity), data2);
				double t2 = time_ms();
				printf("L=%d items=%ld read time=%f bandwidth=%d bytes \r\n", 20,i, t2 - t1, oram.request_bytes);
				if (data2 != data1)
				{
					printf("error!\r\n");
				}
			}
		}
}

void testMyhashtable()
{
	Myhastable<double> ht(1024 * 1024 * 1024, 1);
	Mem20 m = { 0 };
	m.bytes[19] = 1;
	double v,v2;
	ht.Add(m.bytes, 1212);
	ht.ReadValue(m.bytes, &v2);
	printf("v2=%f\r\n", v2);
	unordered_map<int, int> map(100);
}
void testORAMResize()
{
	PathORAM<long long> p(4);
	for (int i = 0; i < p.capacity; i++)
	{
		p.write(i, i * 2);
	}
	p.SetL(63);
	long long d=99;
	p.write(3, d);
	long long e=p.read(3);
	printf("d=%ld e=%ld\r\n", d, e);

}
void testORAMResizeSpeed()
{
	int l = 4;
	PathORAM<long long> oram(l);
	int L = 64;
	for (int i = 0; i < oram.capacity; i++)
	{
		oram.write(i, i * 2);
	}
	//for (int i = 10; i < L; i++)
	//{
	//	oram.SetL(i);
	//	long long data, data2;
	//	oram.write(6, 11);
	//	data2 = oram.read(5);
	//	printf("data2=%ld\r\n", data2);
	//}
	for (int i = l+1; i < L; i++)
	{
		long long data = rand64() ;
		long long addr = rand64()%oram.capacity;
		oram.SetL(i);
		double t1 = time_ms();		
	//	oram.single_round_access("write",addr, data);
		oram.write(addr, data);
		double t2 = time_ms();
		long long data2=0;
		data2=oram.read(addr);
	//	oram.single_round_access("read", addr, data2);
		if (data != data2)
		{
			printf("error ! L=%d\r\n",i);
		}
		else
		{
			printf("OK ! L=%d\r\n", i);
		}
		printf(" L=%d read time=%lf\r\n", i,t2-t1);
	//	oram.single_round_access_complete();//需要调用这个才能洗牌
	
	}
}
void testORAMShuffer()
{
	PathORAM<long long> p(3);
	long long  v = 100;
	long long vv = 0;
//	p.single_round_access("write", 1, v);
//	p.single_round_access("read", 1, vv);
//	printf("vv=%ld", vv);
//	p.dump();
//	getchar();
	for (int i = 0; i < p.capacity; i++)
	{
		long long v2 =  2*i+100;
		//p.single_round_access("write", i, v2);
		p.write(i, v2);
	}
	
	//for (int i = 0; i < p.capacity; i++)
	//{
	//	int v2 = 0;
	//	p.access("read", i, v2);
	//	printf("read i=%d v2=%d\r\n", i, v2);
	//}
	//for (int i = 0; i < 100; i++)
	//{
	//	v = 100 + i;
	//	printf("\r\n times=%d write (2,%d)\r\n", i,v);
	//	p.access("write", 2, v);
	//	p.dump();
	//	getchar();
	//}

	//int v2;
	//p.access("read", 2, v2);
	//for (int i = 0; i < p.capacity; i++)
	//{
	//	int v2;
	//	p.single_round_access("read", i, v2);
	//	printf("%d %d\r\n", i, v2);
	//}
	//int v2;
	//p.single_round_access("read", 3, v2);
	p.dump();
	//printf("\r\n read =%d", v2);


}

void testORAMStashOverflow()
{
	int L = 20; //10 15 20 25
	PathORAM<long long> p(L);

	char mem[64] = { 0 };
	printf("%s testORAMStashOverflow start Z_block =%d: \r\n",  currentTime(mem), Z_block);
	int k = 0;
	long long accessCount = 0;
	long long e3 = 0,e4=0,e5=0,e6=0;
	for (int addr = 0; addr < p.capacity*10000; addr++)
	{
		addr = addr % p.capacity;
		long long data1 = addr;
		p.single_round_access("write", addr, data1);
		//p.single_round_access("read", j, data1);
		for(int i=1;i<=L;i++)
		{ 
			auto v = p.oram[i-1][""];
		//	int d = v.head.maps.size();
		//	printf("size=%d \r\n", d);

			int c = v.head.maps.size();//每一个map包含2个small block
			if (c >= 3)//4)//6)//Z_block
			{
				e3++;
				//printf("%s L=%d addr=%d size=%d\r\n", currentTime(mem),i, addr,c );
			}
			if (c >= 4)
			{
				e4++;
			}
			if (c >= 5)
			{
				e5++;
			}
			if (c >= 6)
			{
				e6++;
			}
			if (c >= 7)
			{
				printf("c=%d! \r\n", c);
			}
			accessCount++;
		}

		int size = p.stash_L.size();
		if(size>0)
		{ 
			printf("%s stash_L size=%d\r\n", currentTime(mem),size);
		}

		if (k++ % 10000 == 0)
		{
			printf("%s current progress: accessCount=%ld e3=%d e4=%d e5=%d e6=%d L=%d Z_block=%d k=%d\r\n", currentTime(mem), accessCount,e3,e4,e5,e6,L, Z_block,k);
		}
	}
	printf("%s Test complete \r\n", currentTime(mem));
}

void testORAMCorrectness()
{
	PathORAM<long long> p(20);
	int L = 20;

	for (int j = 0; j < p.capacity; j++)
	{
		long long data1 = j+100;
		p.single_round_access("write", j, data1);
	}
	for (int j = 0; j < p.capacity; j++)
	{
		long long data2 = j + 100;
		long long data1;
		p.single_round_access("read", j, data1);
		if (data1 != data2)
		{
			printf("error! data1=%ld data2=%ld j=%d\r\n", data1, data2, j);
		}
	}
	printf("Test complete!\r\n");
}
void ORAMDemo()
{
	PathORAM<long long> p(4);
	p.write(5, 99);
	p.dump();
	//Tree 1: "" (a = 0 d0 = 1 d1 = -1 node = 0)();
	//Tree 2: "1" ()(); "" (a = 0 d0 = -1 d1 = 5 node = 1)(); "0" ()();
	//Tree 3: "0" ()(); "11" ()(); "10" ()(); "1" (a = 1 d0 = 14 d1 = -1 node = 5)(); "" ()();
	//Tree 4: "" ()(); "110" ()(); "0" ()(); "11" (a = 2 d0 = 0 d1 = 99 node = 14)(); "10" ()(); "1" ()(); "111" ()();
}

#define Block_size_bytes 1 //1024
struct data1024
{
	long long abc[Block_size_bytes];
};

void ORAMBigBlock()
{
	//LLORAM1024 oram(10);
	//int c = pow(2, 10) *1024;
	//for (int i = 0; i < c; i++)
	//{
	//	printf("write =%ld\r\n", i);
	//	oram.write(i, i * 2);
	//}
	//long long v=oram.Read(100);
	//printf("value =%ld", v);
	PathORAM< data1024> p(15);
	data1024 data1;
	double t1 = time_ms();

	p.single_round_access("write", 1, data1);
	double t2 = time_ms();
	printf("time=%lf (ms)\r\n", (t2 - t1) );

	for (long long i = 0; i < p.capacity; i++)
	{
		data1.abc[i % Block_size_bytes] = i;
		double t3 = time_ms();
		p.single_round_access("write", i%p.capacity, data1);
		double t4 = time_ms();
		printf("height=%d i=%d time=%lf (ms) per keyword time=%lf Block_size_bytes=%d speed=%lf\r\n",p.L, i,(t4 - t3), (t4 - t3)/ (double)(Block_size_bytes), (Block_size_bytes), (double)(Block_size_bytes)/(t4-t3)*1000);
	}

	//printf("time=%lf (ms)", (t2 - t1)/10);
}
void testORAMBandwidth()
{
	PathORAM< data1024> p(12);
	data1024 data1;
	double t1 = time_ms();

	p.single_round_access("write", 1, data1);
	double t2 = time_ms();
	printf("Z_block=%d time=%lf (ms)\r\n", Z_block,(t2 - t1));

	for (long long i = 0; i < p.capacity; i++)
	{
		data1.abc[i % Block_size_bytes] = i;
		double t3 = time_ms();
		p.single_round_access("write", i%p.capacity, data1);
		double t4 = time_ms();
	//	printf("height=%d i=%d time=%lf (ms) per keyword time=%lf Block_size_bytes=%d speed=%lf\r\n", p.L, i, (t4 - t3), (t4 - t3) / (double)(Block_size_bytes), (Block_size_bytes), (double)(Block_size_bytes) / (t4 - t3) * 1000);
		printf("bandwidth=%d, height=%d i=%d time=%lf (ms) per keyword time=%lf Block_size_bytes=%d speed=%lf\r\n",p.request_bytes, p.L, i, (t4 - t3), (t4 - t3) / (double)(Block_size_bytes), (Block_size_bytes), (double)(Block_size_bytes) / (t4 - t3) * 1000);	
	}
}

//-------------------------------------------------------------------------------
//小数据块的实验，判断 空和满的时候，是否存在读写的效率差别
#define Block_size_bytes2 16 //
struct data16
{
	long long abc[Block_size_bytes2];
};
void testORAMFullWriteTime()
{
	PathORAM< data16> p(16);
	data16 data1;
	double t1 = time_ms();

	p.single_round_access("write", 1, data1);
	double t2 = time_ms();
	printf("Z_block=%d time=%lf (ms)\r\n", Z_block, (t2 - t1));

	for (long long i = 0; i < p.capacity; i++)
	{
		data1.abc[i % Block_size_bytes2] = i;
		double t3 = time_ms();
		p.single_round_access("write", i%p.capacity, data1);
		double t4 = time_ms();
		//	printf("height=%d i=%d time=%lf (ms) per keyword time=%lf Block_size_bytes=%d speed=%lf\r\n", p.L, i, (t4 - t3), (t4 - t3) / (double)(Block_size_bytes), (Block_size_bytes), (double)(Block_size_bytes) / (t4 - t3) * 1000);
		if (i < 10 || (i > p.capacity - 10) ||(i %10000==0))
		{
			printf("bandwidth=%d, height=%d i=%d time=%lf (ms) per keyword time=%lf Block_size_bytes=%d speed=%lf\r\n", p.request_bytes, p.L, i, (t4 - t3), (t4 - t3) / (double)(Block_size_bytes), (Block_size_bytes), (double)(Block_size_bytes) / (t4 - t3) * 1000);
		}
		if (i % 10000 == 0)
		{
			//printf("i=%lld \r\n", i);
		}
	}
}
//-----------------------------------
void testORAMDistribution()
{
	PathORAM<long long> p(5);
	for (int i = 0; i < p.capacity; i++)
	{
		p.write(i, i * 10);
	};
	for (int i = 0; i < 100; i++)
	{
		//int c = rand() % p.capacity;
		//p.write(c, c * 10);
		p.write(0, 99);		
		p.dump();
		getchar();
	}
	p.dump();
	//Tree 1: "" (a = 0 d0 = 1 d1 = -1 node = 0)();
	//Tree 2: "1" ()(); "" (a = 0 d0 = -1 d1 = 5 node = 1)(); "0" ()();
	//Tree 3: "0" ()(); "11" ()(); "10" ()(); "1" (a = 1 d0 = 14 d1 = -1 node = 5)(); "" ()();
	//Tree 4: "" ()(); "110" ()(); "0" ()(); "11" (a = 2 d0 = 0 d1 = 99 node = 14)(); "10" ()(); "1" ()(); "111" ()();
}

void test()
{
	testORAMDistribution(); getchar();
	//testORAMFullWriteTime(); getchar();
	//testORAMBandwidth(); getchar();
	//ORAMBigBlock(); getchar();
	ORAMDemo(); getchar();
	//testORAMResize(); getchar();
	//testORAMResizeSpeed(); getchar();
	//testORAMCorrectness(); getchar();
	testORAMStashOverflow(); getchar();
	testORAMShuffer(); getchar();
	testORAMResize(); getchar();
	//testMyhashtable(); getchar();

	testFixedSizePathORAMInsertSpeed(); getchar();
	testPathORAMInsertSpeed(); getchar();
	//testHashtable(); getchar();
	testHashtablePerformance(); getchar();
	//testSingleRound(); getchar();
}
*/


void test1()
{
	ORAMtree tree(5);
	//for (int i = 0; i < tree.capacity/2; i++)
	//{
		//tree.add(IntToStr(i), i * 2);
	//}
	tree.add("keyword", 99);
	tree.add("keyword", 100);
	tree.add("keyword", 101);
//	tree.dump();
//	getchar();
	tree.add("keyword2", 1);
//	tree.dump();
//	getchar();
	tree.add("keyword2", 2);
//	tree.dump();
//	getchar();

//	for (int i = 0; i < 1000; i++)
//	{
//		tree.add(IntToStr(i), i * 100);
//	}
	vector<ull> v;
	//tree.dump(); getchar();
	tree.search("keyword", v);
	tree.search("keyword2", v);
	//tree.search("1", v);
	//tree.dump(); getchar();
	tree.search("keyword", v);
	tree.search("keyword", v);
	tree.dumpLevel();
}
void test2()
{
	ORAMtree tree(15);
	tree.add("keyword", 99);
	tree.add("keyword", 100);
	tree.add("keyword", 101);
	//	tree.dump();
	//	getchar();
	tree.add("keyword2", 1);
	//	tree.dump();
	//	getchar();
	tree.add("keyword2", 2);
	for (int i = 0; i < tree.P.capacity / 2; i++)
	{
		tree.add(IntToStr(i), i * 2);
	}

	//	tree.dump();
	//	getchar();
	//	for (int i = 0; i < 1000; i++)
	//	{
	//		tree.add(IntToStr(i), i * 100);
	//	}
	vector<ull> v;
	//tree.dump(); getchar();

	tree.search("keyword", v);



	tree.search("keyword2", v);
	//tree.search("1", v);
	//tree.dump(); getchar();
	tree.search("keyword", v);
	tree.search("keyword", v);
}
void test3()
{
	ORAMtree tree(4,4,4);
	for (int i = 0; i < tree.P.capacity*4; i++)
	{
		tree.add(IntToStr(i), 100 + i, true);
	}
//	tree.add("a", 99);

	//tree.add("a", 100);


	vector<ull> v;
	//tree.dump(); getchar();
//	for(int i=0;i<1000;i++) tree.search("1", v,false);
	tree.dump();
	tree.dumpStashUsage();
}
void testCorrectness()
{
	ORAMtree tree(10);
	int c = 0;
	for (int i = 0; i < tree.P.capacity; i++)
	{
		tree.add(IntToStr(i), 100 + i);
	}
	//tree.dump();
	for (int i = 0; i < tree.P.capacity; i++)
	{
		vector<ull> ids;
		tree.search(IntToStr(i), ids,false);
		if (ids.size() == 0)
		{
			printf("\r\n error : i=%d", i);
			c++;
		}
		else
		{
			if (ids[0] != 100 + i)
			{
				printf("\r\n error id : i=%d ids[0]=%lld", i,ids[0]);
				c++;
			}
		}
	}
	if(c==0) printf("\r\n testing OK!");
	else
		printf("\r\n errors=%d", c);
}
void testCorrectnessEvict()
{
	ORAMtree tree(7);
	int c = 0;
	vector<ull> ids;
	vector<ull> ids2;
	for (int i = 0; i < tree.P.capacity/2; i++)
	{
		ids.push_back(i);
		ids2.push_back(1000+i);
	}
	int len = ids.size();
	tree.add(IntToStr(1), ids);
	tree.add(IntToStr(2), ids2);
	//tree.dumpdata();
	//getchar();
	ORAMtree temp1, temp2;
	for (int i = 0; i < 10000; i++)
	{
		temp1 = tree;
		if (i == 1)
		{
			//tree.dumpdata();
		//	printf("error1!");
		}
		if (i == 46)
		{
		//	tree.dumpdata();
		//	printf("error1!");
		}
		tree.search(IntToStr(1), ids, false);
		if (i == 1)
		{
		//	tree.dumpdata();
		//	printf("error1!");
		}
		if (i == 46)
		{
		//	tree.dumpdata();
		//	printf("error2!");
		}
		if (ids.size() != len)
		{
			printf("\r\n i=%d errors=%d != %d\r\n", i, ids.size(), len);
			printf("temp1 ----------------------\r\n");
			temp1.dumpdata();
			printf("temp3 ----------------------\r\n");
			tree.dumpdata();
			getchar();
		}
		temp2 = tree;
		tree.search(IntToStr(2), ids2, false);
		if (i == 1)
		{
			//tree.dumpdata();
		//	printf("error1!");
		}
		if (ids2.size() != len)
		{
			printf("\r\n i=%d errors=%d != %d\r\n",i, ids2.size(),len);
			printf("temp1 ----------------------\r\n");
			temp1.dumpdata();
			printf("temp2 ----------------------\r\n");
			temp2.dumpdata();
			printf("temp3 ----------------------\r\n");
			tree.dumpdata();
			getchar();
		}

	}
	printf("\r\n test OK !\r\n");
}
void testCorrectnessEvict2()
{
	ORAMtree tree(15);
	vector<ull> ids;
	vector<ull> ids2;
	for (int i = 0; i < tree.P.capacity ; i++)
	{
		ids.push_back(i);
	}
	int len = ids.size();
	tree.add("1", ids, true);
	int c1 = ids.size();
	for (int i = 0; i < 10000; i++)
	{
		tree.search("1", ids2, false);
		tree.Evict();
		if (ids2.size() != c1)
		{
			printf("error i=%d ids2.size()=%d c1=%d\r\n", i,ids2.size(),c1);
			getchar();
		}
	}
	//tree.dumpdata();
	//getchar();

	printf("\r\n test OK !\r\n");
}
void testCorrectness2()
{
	ORAMtree tree(10);
	int c = 0;
	for (int i = 0; i < tree.P.capacity/10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			tree.add(IntToStr(i), 100 + i+j);
		}
	}
	//tree.dump();
	for (int i = 0; i < tree.P.capacity/10; i++)
	{
		vector<ull> ids;
		tree.search(IntToStr(i), ids, false);
		if (ids.size() != 10)
		{
			printf("\r\n error : i=%d", i);
			c++;
		}
		else
		{
			for (int j = 0; j < 10; j++)
			{
				if (ids[j] != 100 + i+j)
				{
					printf("\r\n error id : i=%d ids[%d]=%lld", i, j,ids[0]);
					c++;
				}
			}
		}
	}
	if (c == 0) printf("\r\n testing OK!");
	else
		printf("\r\n errors=%d", c);
}
//test deletions
void testCorrectness3()
{
	ORAMtree tree(12);
	int c = 0;
	vector<ull> ids;
	tree.add("a", 100);
	tree.add("a", 101);
	tree.add("a", 102);
	for (int i = 0; i < tree.P.capacity / 100; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			tree.add(IntToStr(i), 100 + i + j);
		}
	}
	for (int i = 0; i < tree.P.capacity / 100; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			tree.del(IntToStr(i), 100 + i + j);
		}
		tree.search(IntToStr(i), ids, false);
		if (ids.size() > 0)
		{
			printf("\r\n error : i=%d", i);
			c++;
		}
	}
	tree.del("a", 101);
	tree.search("a", ids);

	if (c == 0) printf("\r\n testing OK!");
	else
		printf("\r\n errors=%d", c);
}
void testCorrectness4()
{
	ORAMtree tree(12);
	int c = 0;
	vector<ull> ids= { 100,101,102,103,104 };
	tree.add("a", ids);
	tree.del("a", 103);
	tree.search("a", ids);

	if (c == 0) printf("\r\n testing OK!");
	else
		printf("\r\n errors=%d", c);
}
void testDistribution()
{
	double opCount = 0;
	for (int L = 7; L <= 25; L++)
	{
		ORAMtree tree(L,12,8);
		double t1 = time_ms();
		opCount = 0;
		for (int i = 0; i < tree.P.capacity/2; i++)
		{
			tree.add(IntToStr(i), 100 + i);
			opCount++;
		}
		double t2 = time_ms();
		/*
		tree.add("1", 101);
	//	tree.dump();
		tree.add("2", 102);
	//	tree.dump();
		tree.add("3", 103);
		tree.add("4", 104);
		tree.add("5", 105);
		tree.add("6", 106);
		tree.dump();
		tree.add("7", 107);
		tree.add("8", 108);
		tree.add("9", 109);		tree.add("10", 110); tree.add("11", 111); tree.add("12", 112); tree.add("13", 113);*/
		//for (int i = 1; i <= 20; i++)
		//{
		//	tree.add(IntToStr(i), 100+i);
		//}
	//	tree.dumpLevel();
		vector<ull> ids;
		tree.search("1", ids);
	//	tree.dumpLevel();
	//	getchar();
	//	vector<ulong> v;
		//for(int i=0;i<10000;i++)	tree.search("1", v,false);
		printf("\r\n L=%d S=%d Z=%d insertion time: %lf (ms)/%d blocks", L,tree.P.S,tree.P.Z, t2 - t1,opCount);
		Log("distribution.txt", "\r\n L=%d S=%d Z=%d B=%d (bytes) capacity=%lld op=%lf insertion time: %lf (ms) speed:%lf (entry/ms) insertion items:%lld exceedS:%d max_S:%d", L, tree.P.S, tree.P.Z, sizeof(DataBlock),tree.P.capacity, opCount, t2 - t1, opCount / (t2 - t1), tree.P.capacity, tree.P.n_root_exceed_S,tree.P.max_S);
		//tree.dump();
		tree.dumpLevel();
	}
}
void testRootExceedS()
{
	ORAMtree tree(15,10,10);
	vector<ull> ids;
	ull total = 0;
	for (int i = 0; i < tree.P.capacity / 100; i++)
	{	
		for (int j = 0; j < 2; j++)
		{
			tree.add(IntToStr(i), i * 2+j); total++;
		}
	}
	for(int j=0;j<100;j++)
	for (int i = 0; i < tree.P.capacity; i++)
	{
		tree.search(IntToStr(i%(tree.P.capacity / 100)),ids,false);
	}
	//tree.dump();
	printf("\r\n Exceed s=%d total=%lld", tree.P.n_root_exceed_S, total);
}
void testTime()
{
	int L = 5;
	int S = 6;
	int Z = 6;
	for (int i = 8; i < 10; i++)
	{
		ORAMtree t(i, S,Z);		
	}
}
void testmap()
{
	unordered_map<int, int> ff;
	ff.reserve(1024*1024*1024*8);
	;
	for (int i = 0; i < 1024; i++)
	{
		ff[i] = i + 100;
		printf("\r\n max=%lld %d  bucketcount=%d bucketsize=%d", ff.max_bucket_count(),i, ff.bucket_count(),ff.bucket_size(i));
	}	
}

void testefficiency()
{
	int L = 16;
	int S = 4;
	int Z = 4;
	vector<ull> ids;
	ORAMtree tree(L, S, Z);
	double t1 = time_ms();
	tree.add("10", 88);
	tree.add("10", 99);
	tree.add("10", 100);
	tree.del("10", 88);
	for (int i = 0; i < tree.P.capacity*Z*0.7; i++)
	{
		tree.add(IntToStr(i), 100 + i,true);
	}
	for (int i = 0; i < tree.P.capacity*Z*0.7 ; i++)
	{
		tree.search(IntToStr(i), ids,false);
	}
	tree.dumpLevel();

	tree.search("10", ids);
	tree.search("10", ids);
	tree.search("10", ids);
	//tree.search("abc",)
}
void exp1_loadfactor()
{
	int L = 14;//10 12 14
	int S = 6;
	int Z = 6;
	vector<ull> ids;
	ORAMtree tree(L, S, Z);
	double t1 = time_ms();
//	tree.add("10", 88);
	//tree.add("10", 99);
	//tree.add("10", 100);
	//tree.del("10", 88);
	double beta =0;
	ull c = tree.P.capacity*Z*0.05;
	for (int i = 0; i < tree.P.capacity*Z; i++)
	{
		if ((i%c)==0)
		{
			beta = (double)i/(tree.P.capacity*Z);
			printf("\r\n beta=%lf", beta);
			tree.dumpStashUsage();
			printf("\r\n %lf---------------------", beta);

		}
		tree.add(IntToStr(i), 100 + i, true);
	//	tree.search(IntToStr(i), ids, false); //插入搜索后 聚集更多，（如果产生了聚集）
	//	tree.search(IntToStr(i), ids, false);
	//	tree.search(IntToStr(i), ids, false);
	//	tree.search(IntToStr(i), ids, false);
	//	tree.search(IntToStr(i), ids, false);
	}
	//tree.dump();


//	for (int i = 0; i < tree.capacity*Z*0.7; i++)
//	{
//		tree.search(IntToStr(i), ids, false);
//	}
//	tree.dumpLevel();
	tree.dumpStashUsage();

	//tree.search("10", ids);
	//tree.search("10", ids);
	//tree.search("10", ids);
	//tree.search("abc",)
}
void exp2_stashsize()
{
	int L = 0;
	int S = 0;
	int Z = 0;
	vector<ull> ids;
	for (L = 10; L <= 20; L+=2)
	{
		for (Z = 4; Z <= 8; Z+=2)
		{
			S = Z;
			ORAMtree tree(L, S, Z);
			double t1 = time_ms();

			double beta = 0;
			//ulong c = tree.capacity*Z*0.05;
			for (int i = 0; i < tree.P.capacity; i++) //装载因子beta=1/Z
			{
				tree.add(IntToStr(i), 100 + i, true);
			}
			tree.dumpStashUsage();			
		}
	}
//  tree.dump();
//	for (int i = 0; i < tree.capacity*Z*0.7; i++)
//	{
//		tree.search(IntToStr(i), ids, false);
//	}
//	tree.dumpLevel();
	

	//tree.search("10", ids);
	//tree.search("10", ids);
	//tree.search("10", ids);
	//tree.search("abc",)
}
void exp3_distribution()
{
	double opCount = 0;
	for (int L = 16; L <= 16; L++)
	{
		ORAMtree tree(L, 6, 6);
		double t1 = time_ms();
		opCount = 0;
		for (int i = 0; i < tree.P.capacity; i++)
		{
			tree.add(IntToStr(i), 100 + i);
			opCount++;
		}
		double t2 = time_ms();
		//vector<ulong> ids;
		//tree.search("1", ids);
		//	tree.dumpLevel();
		//	getchar();
		//	vector<ulong> v;
			//for(int i=0;i<10000;i++)	tree.search("1", v,false);
		//printf("\r\n L=%d S=%d Z=%d insertion time: %lf (ms)/%d blocks", L, tree.S, tree.Z, t2 - t1, opCount);
		Log("distribution.txt", "\r\n L=%d S=%d Z=%d B=%d (bytes) capacity=%lld op=%lf insertion time: %lf (ms) speed:%lf (entry/ms) insertion items:%lld exceedS:%d Max_S:%d", L, tree.P.S, tree.P.Z, sizeof(DataBlock), tree.P.capacity, opCount, t2 - t1, opCount / (t2 - t1), tree.P.capacity, tree.P.n_root_exceed_S, tree.P.max_S);
		printf("\r\n L=%d S=%d Z=%d B=%d (bytes) capacity=%lld op=%lf insertion time: %lf (ms) speed:%lf (entry/ms) insertion items:%lld exceedS:%d Max_S:%d", L, tree.P.S, tree.P.Z, sizeof(DataBlock), tree.P.capacity, opCount, t2 - t1, opCount / (t2 - t1), tree.P.capacity, tree.P.n_root_exceed_S, tree.P.max_S);

		//tree.dump();
		tree.dumpLevel();
	}
}
void exp4_bandwidth()
{
	// BLOCK_SIZE_B 1 32 64
	//ORAMtree tree1(32, 4, 4);
	//getchar();
	vector<ull> ids;
	//int L = 16;


	double t1 = time_ms();
	for (int L = 10; L <= 32; L+=2)
	{
		ORAMtree tree(L, 4, 4);
	//	for (int i = 0; i < tree.capacity / 2; i++)
	//	{
	//		tree.add(IntToStr(i), 100 + i);
	//	}
		double t2 = time_ms();
		tree.P.band_width = 0;
		tree.add(IntToStr(L) +"100", 12345);
		printf("\r\n addition:band_width=%d(bytes) u=%d L=%d Z=%d", tree.P.band_width, BLOCK_SIZE_B, tree.P.L, tree.P.Z);

		tree.P.band_width = 0;
		tree.del(IntToStr(L) + "100", 12345);
		printf("\r\n lazy deletion:band_width=%d(bytes) u=%d L=%d Z=%d", tree.P.band_width, BLOCK_SIZE_B, tree.P.L, tree.P.Z);

	}
	printf("\r\n--------------------------");
	for (int L = 10; L <= 32; L += 2)
	{
		ORAMtree tree(L, 4, 4);
		//	for (int i = 0; i < tree.capacity / 2; i++)
		//	{
		//		tree.add(IntToStr(i), 100 + i);
		//	}

		for (int i = 0; i < 1; i++)
		{
			tree.add("a1", 1000);
		}
		tree.P.band_width = 0;
		tree.search("a1", ids,false); //r_w=1
		printf("\r\n r_w=1 search:band_width=%d(bytes) u=%d L=%d Z=%d", tree.P.band_width, BLOCK_SIZE_B, tree.P.L, tree.P.Z);

		for (int i = 0; i < 25; i++)
		{
			tree.add("a2", 1000 + i);
		}
		tree.P.band_width = 0;
		tree.search("a2", ids,false); //r_w=50
		printf("\r\n r_w=25 search:band_width=%d(bytes) u=%d L=%d Z=%d", tree.P.band_width, BLOCK_SIZE_B, tree.P.L, tree.P.Z);

		for (int i = 0; i < 50; i++)
		{
			tree.add("a3", i + 1000);
		}
		tree.P.band_width = 0;
		tree.search("a3", ids,false); //r_w=5000
		printf("\r\n r_w=50 search:band_width=%d(bytes) u=%d L=%d Z=%d", tree.P.band_width, BLOCK_SIZE_B, tree.P.L, tree.P.Z);
	}
}

void exp5_insertion_speed()
{
	// BLOCK_SIZE_B 1 32
	int Z = 6;// 4 6
	vector<ull> ids;
	//int L = 16;

	double t1 = time_ms();
	int counter = 0;
	for (int L = 10; L <= 32; L += 2)
	{
		ORAMtree tree(L, Z, Z);
		counter = 0;
		double t1 = time_ms();
			for (int i = 0; i < tree.P.capacity / 2; i++)
			{
				tree.add(IntToStr(i), 100 + i);
				counter++;
				if (counter > 1000) break;
			}
		double t2 = time_ms();
		
		tree.P.band_width = 0;
		tree.add(IntToStr(L) + "100", 12345);
		printf("\r\n insertion speed %lf (pairs/ms) u=%d L=%d Z=%d", counter*BLOCK_SIZE_B /(t2-t1), BLOCK_SIZE_B, tree.P.L, tree.P.Z);
	}
}
void exp6_search_time()
{
	// BLOCK_SIZE_B (u) 1 32 64 128
	int Z = 4;// 4 6
	vector<ull> ids;
	int r = 200;//1 50 100 150 200
	//int L = 16;

	double t1 = time_ms();
	int counter = 0;
	for (int L = 10; L <= 32; L += 2)
	{
		ORAMtree tree(L, Z, Z);
		counter = 0;
				
		for (int i = 0; i < r; i++)
		{
			tree.add("100", 100 + i);
			counter++;
			if (counter > 1000) break;
		}
		
		tree.P.band_width = 0;
		double t1 = time_ms();
		tree.search("100", ids,false);
		double t2 = time_ms();
		printf("\r\n search time %lf (ms) r=%d u=%d L=%d Z=%d", (t2 - t1), r,BLOCK_SIZE_B, tree.P.L, tree.P.Z);
	}
}

void testInvertedIndex()
{
	CInvertedIndex index;
	index.LoadDirToInvertedIndex("E:\\OBindex\\test");
	printf("N=%lld m=%lld n=%lld \r\n", index.N, index.m, index.n);
	index.InsertFile("E:\\OBindex\\test2\\ee.txt");
	printf("N=%lld m=%lld n=%lld \r\n", index.N, index.m, index.n);
	getchar();
//	index.Save();
	index.Load();
	printf("N=%lld m=%lld n=%lld \r\n", index.N, index.m, index.n);
	getchar();
}
void testLocalSetup()
{
	CInvertedIndex index;
	index.LoadDirToInvertedIndex("E:\\OBindex\\test");
	ORAMtree r(10);
	r.SetupLocal(index.DB);
	r.dump();
	vector<ull> ids;
	r.search("a",ids,true);
	//printf("stash=%d\r\n", r.stash.size());
	r.dumpStashUsage();
	getchar();
}
CInvertedIndex g_index;


void ShowHelp()
{
	printf("-cash  # enter the cash SSE.\r\n");
	printf(" -testsearch 1000 keyword1 keyword2 keyword3  # search each keyword 1000 times.\r\n");
	printf(" -testsearch 1000 keyword1 keyword2 keyword3  # search each keyword 1000 times; watch the stash.\r\n");
	printf("-del w 100  #delete (w, 100)\r\n ");
	printf("-addlocalrange w 100 200 #insert (w,100),(w,101),...(w,200) into the stash\r\n");
	printf("-addrange w 100 200  #insert (w,100),(w,101),...(w,200) into the index\r\n");
	printf("-dump #dump the tree\r\n");
	printf("-add w 100  #add a (w,100) pair\r\n");
	printf("-L #set the tree height\r\n");
	printf("-level  #dump the load factor of each level\r\n");
	printf("-path  #set to the PATH-ORAM eviction algorithm\r\n");
	printf("-b  #set to the KNNEA eviction algorithm \r\n");
	printf("-loadstash 100000 1000 #load the inverted index to the local stash N=100000 m=1000\r\n");
	printf("-save  #save the oblivious index\r\n");
	printf("-load  #load the oblivious index\r\n");
	printf("-info  #show the information\r\n");

};


void testCMD(ORAMtree &ORAMtree)
{
	//	vb.SetIndexMode(true);//设置优化版本的最小索引
	string line;
	cout << "please input a keyword for search:" << endl;
	while (getline(cin, line))//getline函数可以设置为getline(cin,line,' ')形式，那么就会以' '为分界来读取单词    
	{
		vector<string> k;
		split(line, " ", k);
		if (_strcmpi(k[0].c_str(), "-help") == 0)
		{//显示帮助
			ShowHelp();
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-cash") == 0)//插入1个 (w,id) pair
		{
			printf("cash et al. 's SSE \r\n");
			testCMDCash();
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-testsearch") == 0)//测试搜索，观察stash的大小
		{
			vector<string> k;
			split(line, " ", k);
			double t1 = time_ms();
			if (k.size() < 3)
			{
				printf("size <3;\r\n");
				printf("eg: -testsearch 1000 keyword1 keyword2 keyword3");
				continue;
			}
			int times = atoi(k[1].c_str());
			vector<ull> ids;
			for (int i = 0; i < times; i++)
			{
				for (int x = 2; x < k.size(); x++)
				{
					if (_kbhit()) {
						i = times; break;
					};
					double t3 = time_ms();
					ORAMtree.search(k[x], ids, false);
					double t4 = time_ms();
					Log("exp.txt", "【%d】 search %s, results=%d, time=%lf, stash=%d\r\n",i, k[x].c_str(), ids.size(), t4-t3,ORAMtree.stash.size());
					if (ORAMtree.stash.size() > ORAMtree.P.max_Stash_Evict)
					{
						double t5 = time_ms();
						ORAMtree.Evict();//激发驱逐操作
						double t6 = time_ms();
						Log("exp.txt", "evict  algorithm=%d time=%lf,stash=%d\r\n", ORAMtree.P.shuffle_choice,t6-t5, ORAMtree.stash.size());
					}
				}
			}
			//ORAMtree.insertBatch(k[1], atoi(k[2].c_str()), atoi(k[3].c_str()));
			double t2 = time_ms();
			ORAMtree.dumpStashUsage();
			Log("exp.txt","testsearch OK; time=%f (ms)\r\n", t2 - t1);
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-del") == 0)//插入1个 (w,id) pair
		{
			vector<string> k;
			split(line, " ", k);
			if (k.size() != 3)
			{
				printf("size !=3;\r\n");
				continue;
			}
			ORAMtree.del(k[1], atoi(k[2].c_str()));
			printf("deletion OK;\r\n");
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-addlocalrange") == 0)//插入多个 (w,id) pair
		{
			vector<string> k;
			split(line, " ", k);
			double t1 = time_ms();
			if (k.size() != 4)
			{
				printf("size !=4;\r\n");
				printf("eg: -addlocalrange w 100 200 # insertion (w,100),(w,101),...(w,200)\r\n");
				continue;
			}
			ORAMtree.insertBatchLocal(k[1], atoi(k[2].c_str()), atoi(k[3].c_str()));
			double t2 = time_ms();
			printf("insertBatchLocal OK; time=%f (ms)\r\n", t2 - t1);
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-addrange") == 0)//插入多个 (w,id) pair
		{
			vector<string> k;
			split(line, " ", k);
			double t1 = time_ms();
			if (k.size() != 4)
			{
				printf("size !=4;\r\n");
				printf("eg: -addrange w 100 200 # insertion (w,100),(w,101),...(w,200)\r\n");
				continue;
			}
			ORAMtree.insertBatch(k[1], atoi(k[2].c_str()), atoi(k[3].c_str()));
			double t2 = time_ms();
			printf("insertBatch OK; time=%f (ms)\r\n", t2 - t1);
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-dump") == 0)//插入1个 (w,id) pair
		{
			ORAMtree.dumpdata();
			printf("dump OK;\r\n");
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-add") == 0)//插入1个 (w,id) pair
		{
			vector<string> k;
			split(line, " ", k);
			if (k.size() != 3)
			{
				printf("size !=3;\r\n");
				continue;
			}
			ORAMtree.add(k[1], atoi(k[2].c_str()));
			printf("insertion OK;\r\n");
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-L") == 0)//
		{
			vector<string> k;
			split(line, " ", k);
			if (k.size() != 2)
			{
				printf("size !=2;\r\n");
				continue;
			}
			ORAMtree.P.L = atoi(k[1].c_str());
			ORAMtree.init();
			ORAMtree.dumpStashUsage();
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-level") == 0)//
		{
			ORAMtree.dumpLevel();
			printf("\r\n dump OK;\r\n");
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-setmaxstash") == 0)//
		{
			vector<string> k;
			split(line, " ", k);
			if (k.size() != 2)
			{
				printf("size !=2;\r\n");
				continue;
			}
			ORAMtree.P.max_Stash_Evict = atoi(k[1].c_str());
			ORAMtree.dumpStashUsage();
			continue;
		}
		//
		if (_strcmpi(k[0].c_str(), "-path") == 0)// pathORAM eviction
		{
			vector<string> k;
			split(line, " ", k);
			ORAMtree.P.shuffle_choice = ALGORITHM_PATHORAM;//老算法 不分区
			ORAMtree.debug.PATH_ORAM_chooseTime = 0;
			double t1 = time_ms();
			if (k.size() == 1)
			{
				ORAMtree.Evict0();
			}
			else
			{
				ORAMtree.Evict0(atoi(k[1].c_str()));//读取并驱除 stash*L*L*倍数 的路径
			}
			double t2 = time_ms();
			printf("non-partition Eviction OK! time=%lf (ms) candidate time=%lf (ms)\r\n", t2 - t1,ORAMtree.debug.PATH_ORAM_chooseTime);
			ORAMtree.dumpStashUsage();
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-b") == 0)// bottom_to_top
		{
			vector<string> k;
			split(line, " ", k);
			ORAMtree.P.shuffle_choice = ALGORITHM_BOTTOM_TO_TOP;//老算法 不分区
			double t1 = time_ms();
			if (k.size() == 1)
			{
				ORAMtree.Evict0();
			}
			else
			{
				ORAMtree.Evict0(atoi(k[1].c_str()));//读取并驱除 stash*L*L*倍数 的路径
			}
			double t2 = time_ms();
			printf("non-partition Eviction OK! time=%lf(ms) deletion Time=%lf(ms)\r\n",t2-t1,ORAMtree.debug.BottomToTop_removeTime);
			ORAMtree.dumpStashUsage();
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-p") == 0)//-pbea
		{
			vector<string> k;
			split(line, " ", k);
			ORAMtree.P.shuffle_choice = ALGORITHM_PBEA;//新算法 分区
			double t1 = time_ms();
			if (k.size() == 1)
			{
				ORAMtree.Evict();
			}
			else
			{
				ORAMtree.Evict(atoi(k[1].c_str()));//读取并驱除 stash*L*L*倍数 的路径
			}
			double t2 = time_ms();
			printf("partition Eviction OK! time=%lf\r\n",t2-t1);
			ORAMtree.dumpStashUsage();
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-loadstash") == 0)
		{
			//vector<string> k;
			//split(line, " ", k);
			if (k.size() != 3)
			{
				printf("e.g., -loadstash 100000 1000 \r\n");
				continue;
			}
			ull N = atoi(k[1].c_str());
			ull m = atoi(k[2].c_str());
			printf("Load index local N=%ld m=%ld...\r\n",N,m);

			double t1 = time_ms();
			if (g_index.DB.size() == 0)
			{
				g_index.Load(N, m);
			}
			else
			{
				printf("already loaded...\r\n");
			}
			double t2 = time_ms();
			printf("loadlocal completed:  time=%f...\r\n",  t2 - t1);
			printf("N=%lld m=%lld n=%lld \r\n", g_index.N, g_index.m, g_index.n);
			double t11 = time_ms();
			//ORAMtree.insertBatchLocal(k[1], atoi(k[2].c_str()), atoi(k[3].c_str()));
			for (auto& v : g_index.DB)
			{
				ORAMtree.add(v.first, v.second, false, false);//不驱逐
			}
			double t22 = time_ms();
			printf("insertion ORAMtree completed:  time=%f...\r\n", t22 - t11);
			continue;
		}

		if (_strcmpi(k[0].c_str(), "-save") == 0)//保存OBI索引
		{
			printf("save the index...\r\n");
			ORAMtree.save();
			printf("index saving completed;\r\n");
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-load") == 0)//保存OBI索引
		{
			printf("load the index...\r\n");
			ORAMtree.load();
			printf("index loaded;\r\n");
			continue;
		}
		if (_strcmpi(k[0].c_str(), "-info") == 0)//保存OBI索引
		{
			ORAMtree.dumpStashUsage();
			ORAMtree.info();
			continue;
		}

			
		int c1 = myhash::counter();
		vector<unsigned long long > ids;
		string w = line;
		ORAMtree.search(w, ids, true);
		int c2 = myhash::counter();
		printf("\r\n pseudo-random %d\r\n\r\n", c2 - c1);
		ORAMtree.dumpStashUsage();

		cout << "please input a keyword for search:" << endl;
		//cout << line << endl;
	}
}

void ProgramStart(int argc, char* argv[])
{
	string src;
	string des;
	int height = 22;
	bool bSetHeight = false;
	ull max_size = -1;//最大N; 
	ull max_m = -1;//最大的m 总关键词数
	bool bOnlineSetup = false;
	printf("\r\n Usage:\r\n", max_size);
	printf("-save  #save the index\r\n", max_size);
	printf("-load #load the index\r\n", max_size);
	printf("-add keyword 100  #add a keyword-identifier pair (keyword,100)\r\n", max_size);
	printf("-info #the index information\r\n");
	printf("-help #show helps\r\n");
	printf(" %s \r\n", Now().c_str());
	printf("\r\n");
	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "--max-size") == 0)
		{
			if (i + 1 < argc)
			{
				src = argv[i + 1];
				max_size = atoi(src.c_str());
				printf("max-size: %lld\r\n", max_size);
			}
			i += 1;			
		}
		if (strcmp(argv[i], "--max-m") == 0)
		{
			if (i + 1 < argc)
			{
				src = argv[i + 1];
				max_m = atoi(src.c_str());
				//printf("max-m: %lld\r\n", max_m);
			}
			i += 1;
		}
	}
	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "--create-inverted-index") == 0)
		{
			printf("Create index :%s ...\r\n",argv[i]);
			double t1 = time_ms();
			if (i + 1 < argc)
			{
				src = argv[i + 1];
				g_index.LoadDirToInvertedIndex(src, max_size);
			}
			i += 1;
			g_index.Save();
			double t2 = time_ms();
			printf("completed!  %s time=%f\r\n", Now().c_str(),t2-t1);
			printf("N=%lld m=%lld n=%lld \r\n", g_index.N, g_index.m, g_index.n);
			return;
		}
		if (strcmp(argv[i], "--set-height") == 0)
		{
			if (i + 1 < argc)
			{
				src = argv[i + 1];
				//g_index.LoadDirToInvertedIndex(src);
				height = atoi(src.c_str());
				bSetHeight = true;
			}
			i += 1;
			g_index.Save();
		}
		if (strcmp(argv[i], "--load-inverted-index") == 0)
		{
			printf("Load index: %s ...\r\n", argv[i]);
			if (max_m != -1)
			{
				printf("max_m=%lld \r\n", max_m);
			}
			double t1 = time_ms();
			g_index.Load(max_size, max_m);
			double t2 = time_ms();
			printf("completed: %s  time=%f...\r\n", argv[i],t2-t1);
			printf("N=%lld m=%lld n=%lld \r\n", g_index.N, g_index.m, g_index.n);
		}
		if (strcmp(argv[i], "--online-setup") == 0)
		{
			bOnlineSetup = true;
		}
		
	}
	if (!bSetHeight)
	{
		if (g_index.DB.size() > 0)
		{		
			printf("set height=%d \r\n", height);
			height = log2(g_index.N) + 1; //设置高度
		}
	}
	ORAMtree ORAMtree(height); //BLOCK_SIZE_B
	printf("ORAMtree Z=%d L=%d\r\n", ORAMtree.P.Z,height);
	if (g_index.DB.size() > 0)
	{
		printf("inserting all the values...\r\n");
		double t1 = time_ms();
	//	for (auto& v : g_index.DB)
	//	{
	//		string w = v.first;
	//		ORAMtree.addLocal(w, g_index.DB[w],false);		
	//	}
		if (bOnlineSetup)
		{
			printf("Online Setup ...\r\n");
			ORAMtree.SetupOnline(g_index.DB);
		}
		else
		{
			printf("Offline Setup ...\r\n");
			ORAMtree.SetupLocal(g_index.DB);
		};
		double t2 = time_ms();		
		printf("insertion complete time=%lf (ms) m=%lld\r\n",t2-t1,g_index.DB.size());
	}
	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "-save") == 0)
		{
			printf("Save oblivious index :%s ...\r\n", argv[i]);
			double t1 = time_ms();
			ORAMtree.save();
			double t2 = time_ms();
			printf("completed!  %s time=%f\r\n", Now().c_str(), t2 - t1);
			printf("N=%d m=%d n=%lld \r\n", g_index.N, g_index.m, g_index.n);
			return;
		}
		if (strcmp(argv[i], "-load") == 0)
		{
			printf("Load oblivious index: %s ...\r\n", argv[i]);
			double t1 = time_ms();
			ORAMtree.load();
			double t2 = time_ms();
			printf("completed: %s  time=%f...\r\n", argv[i], t2 - t1);
			printf("N=%lld m=%lld n=%lld \r\n", g_index.N, g_index.m, g_index.n);
		}
	}

	testCMD(ORAMtree);
}

void testPerformance()
{
	int L = 15;
	int S = 4;
	int Z = 4;
	vector<ull> ids;
	for (int i = 15; i < 23; i++)
	{
		ORAMtree tree(i, S, Z);

		for (int j = 0; j < 1024; j++)
		{
		//	tree.add("w", j);
			ids.push_back(j);
		}
		tree.add("w", ids);
		tree.search("w", ids,true);
	}

	//tree.search("abc",)
}

int main(int c,char* argv[])
{
	//testCorrectnessEvict(); getchar();
	//testCorrectnessEvict2(); getchar();
	//testLocalSetup(); getchar();
	//testPerformance(); getchar(); //论文中的图形数据

	printf("OBI v1.0, programed by zhiqiang wu, wzq@csust.edu.cn\r\n\r\n");
	printf("Eg:\r\n");
	printf("obi --create-inverted-index d:\\myDirectory\r\n");
	printf("obi --load-inverted-index \r\n");
	printf("obi --create-inverted-index d:\\myDirectory -save\r\n");
	printf("obi  --create-inverted-index d:\\myDirectory --online-setup\r\n");// online create index
	printf("obi --set-height 10 --max-size 10000 --max-m 1000\r\n");
	printf("obi -load #load the index\r\n");
	printf("\r\n\r\n");

	ProgramStart(c, argv);
	//testInvertedIndex(); getchar();
   //testmap(); getchar();
   //test1(); getchar();
   //test3(); getchar();
   //	testCorrectness(); getchar();
  //	testCorrectness2(); getchar();
  //	testCorrectness3(); getchar();
  //	testCorrectness4(); getchar();
  //	testefficiency(); getchar();
  //    test2();

	//testDistribution();
	//testRootExceedS();	
	//exp1_loadfactor();
	//exp2_stashsize();
	//exp3_distribution();
	//exp4_bandwidth();
	//exp5_insertion_speed();
	//exp6_search_time();

	getchar();
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门提示: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
