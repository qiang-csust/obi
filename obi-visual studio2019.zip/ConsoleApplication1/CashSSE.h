#pragma once

#include "common.h"
#include "unordered_map"
#include "myhash.h"
#include "myAES.h"
#include <vector>
#include <algorithm>
#include "EII.h"


void testCMDCash();