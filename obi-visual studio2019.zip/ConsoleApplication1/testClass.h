#pragma once
template<typename T>
class testClass
{
public:
	testClass();
	~testClass();
};

template<typename T>
 testClass<T>::testClass()
{
}

template<typename T>
 testClass<T>::~testClass()
{
}
