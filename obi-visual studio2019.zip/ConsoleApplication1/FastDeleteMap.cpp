#include "FastDeleteMap.h"


FastDeleteMap::FastDeleteMap()
{
}

bool LessSortByLeaf2(Slot a, Slot b) 
{ 
	return (a.leaf < b.leaf); 
};
void FastDeleteMap::InitArrange(vector<Slot>& slots)
{
	sort(slots.begin(), slots.end(), LessSortByLeaf2);
	IndexKey before = { 0 };
	IndexKey after = { 0 };
	if (slots.size() >= 1)
	{
		firstEntryKey = slots[0].key;
	};
	for (int i = 0; i < slots.size(); i++)
	{
		if (i == 0)
		{
			if (slots.size() >= 1)
			{
				after = slots[1].key;
			}
			else
			{
				after = { 0 };
			}
		}
		if (i == slots.size() - 1)
		{
			after = { 0 };
		}
		if(i>=1) before = slots[i - 1].key;
		if(i<slots.size()-1) after = slots[i + 1].key;
		MapNode d;
		d.before = before;
		d.after = after;
		d.s = slots[i];
		map[d.s.key] = d;
	}
	m_slots = slots;
}

MapNode FastDeleteMap::ReadNode(IndexKey key)
{	
	MapNode d = { 0 };
	if (map.find(key) == map.end())
	{
		d.bEmpty = true;
		return d;
	}
	d = map[key];
	d.bEmpty = false;
	return d;
}

int ORAMtree::FindOneSlotFromSortedVector(vector<Slot>& slots, ull leaf)
{
	int i = 0;
	int max = slots.size() - 1;
	int min = 0;
	while (true)
	{
		i = (max + min) / 2;
		if (max < min)
		{
			return i;//����ʧ�� ѡ��һ�����������
		};
		if (slots[i].leaf == leaf)
		{
			return i;
		}
		if (slots[i].leaf < leaf)
		{
			min = i + 1;
		}
		if (slots[i].leaf > leaf)
		{

			max = i - 1;
		}
	}
	return -1;
}

MapNode FastDeleteMap::ReadNextNode(IndexKey key)
{
	MapNode d = ReadNode(key);
	MapNode d1 = ReadNode(d.after);
	return d1;
}
MapNode FastDeleteMap::ReadPriorNode(IndexKey key)
{
	MapNode d = ReadNode(key);
	MapNode d1 = ReadNode(d.before);
	return d1;
}


void FastDeleteMap::DeleteEntry(IndexKey key)
{
	MapNode d = ReadNode(key);
	MapNode d1 = ReadNode(d.before);
	MapNode d2 = ReadNode(d.after);
	if(!d1.bEmpty) map[d1.s.key].after = d2.s.key;
	if(!d2.bEmpty) map[d2.s.key].before = d1.s.key;
	map.erase(key);
}

FastDeleteMap::~FastDeleteMap()
{
}
