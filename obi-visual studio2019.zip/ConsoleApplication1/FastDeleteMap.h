#pragma once
#include "ORAMtree.h"
struct MapNode
{
	Slot s;
	IndexKey before;
	IndexKey after;
	bool bEmpty;
};
class FastDeleteMap
{
public:
	FastDeleteMap();
	unordered_map< IndexKey, MapNode, hash_func1, cmp_fun1> map;
	void InitArrange(vector<Slot>& slots);
	MapNode ReadNode(IndexKey key);
	MapNode ReadNextNode(IndexKey key);

	MapNode ReadPriorNode(IndexKey key);

	void DeleteEntry(IndexKey key);
	IndexKey firstEntryKey;
	vector<Slot> m_slots;
	~FastDeleteMap();
};

